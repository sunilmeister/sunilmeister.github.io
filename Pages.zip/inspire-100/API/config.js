const PORT = 3002;
module.exports = {
    port: PORT,
}
// ////////////////////////////////////////////////////
// Author: Sunil Nanda
// ////////////////////////////////////////////////////

function getActiveTileColorBG() {
	return "#5B7C99";
}

function getActiveTileColorFG() {
	return "white";
}

function getInactiveTileColorBG() {
	return "#EAFBFE";
}

function getInactiveTileColorFG() {
	return "#BE5108";
}

function getActiveCaptionColorBG() {
	return "darkgray";
}

function getInactiveCaptionColorBG() {
	return "white";
}


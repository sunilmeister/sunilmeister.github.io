// ////////////////////////////////////////////////////
// Author: Sunil Nanda
// List all releases that you want to provide access to
// The list must be ordered according to creation dates
// The most recent first
// ////////////////////////////////////////////////////

var knownInspireReleases = [
  {rel:"1.0.1", created:"30-Jan-2024"},
];

